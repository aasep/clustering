<form action="" method="POST"> 
Sampai Cluster : <input type="text" name="cluster" value="<?php if(isset($_POST["cluster"])){ echo $_POST["cluster"];}else{echo "";} ?>"><br>
<input type="submit" value="prosess >>> ">
</form>



<?php
##############################
#   CREATOR
#   aseparifyan@pgi-data.com
#   Coding with fun and Love ...
#################################

if (isset($_POST["cluster"])){


include("adodb5/adodb.inc.php");
include("function.php");
$db = newADOConnection('mysqli');

$db->connect("localhost", "admin", "Instance12", "db_agglomerative");
 
// Section 2
$result = $db->execute("SELECT * FROM matriks");
if ($result === false) die("failed");
 


		$i=1;
		while (!$result->EOF) {

				$dataset[$i]['anggota']		= $result->fields["nama"];
				$dataset[$i] ['berat'] 		= $result->fields["berat"];
				$dataset[$i] ['tinggi'] 	= $result->fields["tinggi"];


			$i++;
		    $result->moveNext();
		}



		$z=$i;
		$jml_data=$z-1;
		echo "Jumlah Data= ".$jml_data;
		print_r("<pre>");
		print_r($dataset);
		print_r("</pre>");

		$end_cluster=$jml_data-$_POST["cluster"];

//$jml_data=count($cars)

		############  PERULANGAN AGGLOMERATIVE SEJUMAH DATA #########################
		for ($cluster=1; $cluster <= $end_cluster ; $cluster++) { 

			if($cluster=="1"){

					echo "---------- CLUSTER ".($jml_data-$cluster)."---------------------------------------------------------<br>";

						$step=1;
						$step_mirror=1;
						for ($i=1; $i <= $jml_data-1; $i++) { 


							for ($j=$i+1; $j <= $jml_data ; $j++) { 

								$library1[$step]['anggota']	=$dataset[$i]['anggota'].",".$dataset[$j]['anggota'];
								#---Hitung jarak dg Euclidian Distance ----------#
								$library1[$step]['jarak']	=round(sqrt(pow(($dataset[$i]['berat']-$dataset[$j]['berat']),2) + pow(($dataset[$i]['tinggi']-$dataset[$j]['tinggi']),2)),2);

								$library2[$step]['anggota']	=$dataset[$j]['anggota'].",".$dataset[$i]['anggota'];
								#---Hitung jarak dg Euclidian Distance ----------#
								$library2[$step]['jarak']		=round(sqrt(pow(($dataset[$i]['berat']-$dataset[$j]['berat']),2) + pow(($dataset[$i]['tinggi']-$dataset[$j]['tinggi']),2)),2);

								$step++;
							}

								
							
						}

						/*print_r("<pre>");
						print_r($library1);
						print_r("</pre>");
						echo "---------- Kombinasi MIRoRR------<br>";
						print_r("<pre>");
						print_r($library2);
						print_r("</pre>");*/

						##### MENCARI JARAK KOMBINASI TERPENDEK-------------------------
						//$element2=array();
						$element2=$library1;
						$jarak = array_column($element2, 'jarak');
						array_multisort($jarak, SORT_ASC, $element2);
						echo "<br>---------- Sorting Jarak ------<br>";
						echo "Anggota = ".$element2[0]['anggota'];
						echo "<br>Jarak =".$element2[0]['jarak'];

						$anggota_merge=explode(",",$element2[0]['anggota']);


						/*print_r("<pre>");
						print_r($anggota_merge);
						print_r("</pre>");
*/


						// list array anggota baru / MERGE ROW
						#------------------------------------------------

						echo "<br>---------- LIST CLUSTER  ------<br>";

						$new_arrayname=createNewList($anggota_merge,$element2,$dataset);


						print_r("<pre>");
						print_r($new_arrayname);
						print_r("</pre>");





			}else{

						echo "---------- CLUSTER ".($jml_data-$cluster)."---------------------------------------------------------<br>";
						# STEP 2
						$iterasi2=kombinasiJarak($new_arrayname,$library1,$library2);

						/*echo "---------- KOmbinasi jarak ------<br>";
						print_r("<pre>");
						print_r($iterasi2);
						print_r("</pre>");*/
						//$element=array();
						$element2=$iterasi2;
						$jarak=array();
						$jarak = array_column($iterasi2, 'jarak');
						array_multisort($jarak, SORT_ASC, $element2);
						echo "<br>---------- Sorting Jarak ------<br>";
						echo "Anggota = ".$element2[0]['anggota'];
						echo "<br>Jarak =".$element2[0]['jarak'];
						$anggota_merge=explode(",",$element2[0]['anggota']);


						/*print_r("<pre>");
						print_r($anggota_merge);
						print_r("</pre>");*/


						echo "<br>---------- LIST CLUSTER  ------<br>";
						$new_arrayname=createNewList($anggota_merge,$element2,$dataset);


						print_r("<pre>");
						print_r($new_arrayname);
						print_r("</pre>");







			}




			
		}

		################## END PERULANGAN AGGLOMERATIVE #############################


}



?>
