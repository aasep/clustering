<?php

include("adodb5/adodb.inc.php");
$db = newADOConnection('mysqli');
//$db->connect("34.101.211.53", "root", "", "vbarrio");
$db->connect("localhost", "admin", "Instance12", "db_agglomerative");
 
// Section 2
$result = $db->execute("SELECT * FROM matriks");
if ($result === false) die("failed");
 
// Section 3
/*while (!$result->EOF) {
    for ($i=0, $max=$result->fieldCount(); $i < $max; $i++) {
        print $result->fields[$i].' ';
    }
    $result->moveNext();
    print "<br>\n";
}
*/

$i=1;
		while (!$result->EOF) {
		   

				//echo $result->fields["nama"]."<br>";
				$arrayname[$i]['anggota']	= $result->fields["nama"];
				$arrayname[$i] ['berat'] 	= $result->fields["berat"];
				$arrayname[$i] ['tinggi'] 	= $result->fields["tinggi"];


			$i++;
		    $result->moveNext();
		}

$z=$i;
$jml_data=$z-1;
echo $z;
print_r("<pre>");
print_r($arrayname);
print_r("</pre>");

//$jml_data=count($cars)
echo "---------- Kombinasi------<br>";

$step=1;
$step_mirror=1;
for ($i=1; $i <= $jml_data-1; $i++) { 


	for ($j=$i+1; $j <= $jml_data ; $j++) { 

		$iterasi[$step]['anggota']	=$arrayname[$i]['anggota'].",".$arrayname[$j]['anggota'];
		#---Hitung jarak dg Euclidian Distance ----------#
		$iterasi[$step]['jarak']	=round(sqrt(pow(($arrayname[$i]['berat']-$arrayname[$j]['berat']),2) + pow(($arrayname[$i]['tinggi']-$arrayname[$j]['tinggi']),2)),2);

		$mirror[$step]['anggota']	=$arrayname[$j]['anggota'].",".$arrayname[$i]['anggota'];
		#---Hitung jarak dg Euclidian Distance ----------#
		$mirror[$step]['jarak']		=round(sqrt(pow(($arrayname[$i]['berat']-$arrayname[$j]['berat']),2) + pow(($arrayname[$i]['tinggi']-$arrayname[$j]['tinggi']),2)),2);

		$step++;
	}

		
	
}

print_r("<pre>");
print_r($iterasi);
print_r("</pre>");
echo "---------- Kombinasi MIRoRR------<br>";
print_r("<pre>");
print_r($mirror);
print_r("</pre>");

##### MENCARI JARAK KOMBINASI TERPENDEK-------------------------
$element=$iterasi;
$jarak = array_column($element, 'jarak');
array_multisort($jarak, SORT_ASC, $element);
/*echo "<br>Anggota = ".$min_array[1]['anggota'];
echo "<br>Jarak =".$min_array[1]['jarak'];*/
echo "---------- Sorting Jarak ------<br>";
echo "<br>Anggota = ".$element[0]['anggota'];
echo "<br>Jarak =".$element[0]['jarak'];
$anggota_merge=explode(",",$element[0]['anggota']);


print_r("<pre>");
print_r($anggota_merge);
print_r("</pre>");


/*print_r("<pre>");
print_r($element);
print_r("</pre>");*/




//$prices = array_column($iterasi, 'jarak');
//$element = array_multisort($prices, SORT_DESC, $iterasi);


//$element = array_multisort($types, SORT_ASC, $inventory);
//echo "<br>".$min;
//echo "<br>Anggota = ".$element[1]['anggota'];
//echo "<br>Jarak =".$element[1]['jarak'];
/*print_r("<pre>");
print_r($mirror);
print_r("</pre>");
*/


// list array anggota baru / MERGE ROW
#------------------------------------------------

//$key = array_search('B', array_column($arrayname, 'anggota'));


//echo "<br>Anggota = ".($key+1)."<br>";

/*$keys = array_keys($arrayname);
for($i = 0; $i < count($arrayname); $i++) {
    echo $keys[$i] . "{<br>";
    foreach($arrayname[$keys[$i]] as $key => $value) {
        echo $key . " : " . $value . "<br>";
    }
    echo "}<br>";
}*/

echo "---------- LIST BARU ------<br>";
$jml_anggota_cluster=count($anggota_merge);

$k=2;
$new_arrayname[1]['anggota']	= $element[0]['anggota'];
foreach ($arrayname as $key => $value) {
		$new_found=0;

		for ($init=0; $init < $jml_anggota_cluster; $init++) { 
			
			if($value['anggota']==$anggota_merge[$init]){
				$found=1;
			}else{
				$found=0;
			}

			$new_found=$new_found+$found;

		}
//echo $new_found."<br>";
		if($new_found <= 0 ){ //tidak ketemu
			$new_arrayname[$k]['anggota']	= $value['anggota'];

		}else{


		}

		//$key_old = array_search(40489, array_column($arrayname, 'anggota'));
	// echo   $key . " : " .$value['anggota'] . "<br>";
	 			//$arrayname[$k]['anggota']	= $result->fields["nama"];
				//$arrayname[$k] ['berat'] 	= $result->fields["berat"];
				//$arrayname[$k] ['tinggi'] 	= $result->fields["tinggi"];
	 $k++;
}

print_r("<pre>");
print_r($new_arrayname);
print_r("</pre>");

$search = 'A,C';
$found = array_filter($iterasi,function($v,$k) use ($search){
  return $v['anggota'] == $search;
},ARRAY_FILTER_USE_BOTH); // With latest PHP third parameter is optional.. Available Values:- ARRAY_FILTER_USE_BOTH OR ARRAY_FILTER_USE_KEY  
print_r("<pre>");
$values= print_r(array_values($found));
print_r("</pre>");
//$keys =  print_r(array_keys($found)); 








?>