<?php

/*function countDPA($username){
        global $db;
        $query = " select count(*) as jml_op from  bimbingan_akademik where status='1'  and username='".trim($username)."' and tipe='1' ";
        $RS    = $db->Execute($query);
        $jumlah = $RS->fields['jml_op'];
        return $jumlah;
    }

function getDataProfile($username){
        global $db;
        $data=array();
        $query = " SELECT * FROM user_account WHERE username='$username'  ";

        $RS    = $db->Execute($query);
        $data = $RS->fetchRow();
        return $data;
    }
*/

function createNewList($anggota_merge,$element2,$dataset){

		$jml_anggota_cluster=count($anggota_merge);

		$new_arrayname=array();
		$k=2;
		$new_arrayname[1]['anggota']	= $element2[0]['anggota'];
		foreach ($dataset as $key => $value) {
				$new_found=0;

				for ($init=0; $init < $jml_anggota_cluster; $init++) { 
					
					if($value['anggota']==$anggota_merge[$init]){
						$found=1;
					}else{
						$found=0;
					}

					$new_found=$new_found+$found;

				}
				if($new_found <= 0 ){ //tidak ketemu
					$new_arrayname[$k]['anggota']	= $value['anggota'];
					$k++;
				}else{


				}

			 
		}

		return $new_arrayname;


}
function kombinasiJarak($new_arrayname,$library1,$library2){

		$jml_data=count($new_arrayname);
		$step=1;
		$iterasi2=array();
		$tmp_array=array();
		for ($i=1; $i <= $jml_data-1; $i++) { 


			for ($j=$i+1; $j <= $jml_data ; $j++) { 
				$list_jarak=array();
				$iterasi2[$step]['anggota']	=$new_arrayname[$i]['anggota'].",".$new_arrayname[$j]['anggota'];
				#----betuk array berdasarkan kombinasi------------

				$tmp_array = explode(',',$new_arrayname[$i]['anggota'].",".$new_arrayname[$j]['anggota']);
				$kiri  =explode(',',$new_arrayname[$i]['anggota']);
				$kanan =explode(',',$new_arrayname[$j]['anggota']);
				$jml_kiri =count($kiri);
				$jml_kanan=count($kanan);

				/*print_r("<pre>");
				print_r($tmp_array);
				print_r("</pre>");*/
				#----searcing jarak sesuai kombinasi 
				for ($p=0; $p < $jml_kiri ; $p++) { 

					for ($q=0; $q < $jml_kanan ; $q++) { 
						$agg    = $kiri[$p].",".$kanan[$q];

						if($new_arrayname[$i]['anggota']=="$agg" ||$new_arrayname[$j]['anggota']=="$agg" ){

						}else{
							
							//echo $agg."<br>";
							$search = "$agg";
							$found1 = array_filter($library1,function($v,$k) use ($search){
							  return $v['anggota'] == $search;
							},ARRAY_FILTER_USE_BOTH);  
							/*print_r("<pre>");
							print_r($found1);
							print_r("</pre>");*/
							if (!empty($found1)) {
								$ketemu1= array_values($found1);
		    					array_push($list_jarak,$ketemu1[0]['jarak']);
							}
							
						}
						
						
						
						
					}
					
				}
					for ($m=0; $m < $jml_kiri; $m++) { 

						for ($n=0; $n < $jml_kanan; $n++) { 
							$agg    = $kiri[$m].",".$kanan[$n];

							if($new_arrayname[$i]['anggota']=="$agg" ||$new_arrayname[$j]['anggota']=="$agg" ){

							}else{
							
									//echo $agg." library2 <br>";
									$search = "$agg";
									$found2 = array_filter($library2,function($v,$k) use ($search){
									  return $v['anggota'] == $search;
									},ARRAY_FILTER_USE_BOTH);  
									/*print_r("<pre>");
									print_r($found2);
									print_r("</pre>");*/
									if (!empty($found2)) {
										$ketemu2= array_values($found2);
				    					array_push($list_jarak,$ketemu2[0]['jarak']);
									}
							
							}
						
						}
						
					}



				#----hitung jarak terpendek 
					$new_jarak=min($list_jarak);
					$iterasi2[$step]['jarak']	=$new_jarak;





				$step++;
			}

				
			
		}


		return $iterasi2;

}





















?>