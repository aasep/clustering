<?php

include("adodb5/adodb.inc.php");
$db = newADOConnection('mysqli');
//$db->connect("34.101.211.53", "root", "", "vbarrio");
$db->connect("localhost", "root", "", "mytest");
 
// Section 2
$result = $db->execute("SELECT * FROM users");
if ($result === false) die("failed");
 
// Section 3
while (!$result->EOF) {
    for ($i=0, $max=$result->fieldCount(); $i < $max; $i++) {
        print $result->fields[$i].' ';
    }
    $result->moveNext();
    print "<br>\n";
}


?>